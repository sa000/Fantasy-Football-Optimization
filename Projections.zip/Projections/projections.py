import pandas as pd
import os
import numpy as np


def merge():
	files=os.listdir('data')
	for file in files[1:]:
		position=file[0:2]
		df=pd.read_csv('data/'+file)
		print position
		if position=='QB':
			ffpoints=4*df['passTds']+.04*df['passYds']-df['passInt']+.1*df['rushYds']+6*df['rushTds']
			passing_bonus=np.where(df['passYds']>=300, 3,0)
			total_pts=ffpoints+passing_bonus
		elif position=='RB':
			rushing_bonus=np.where(df['rushYds']>=100,3,0)
			receiving_bonus=np.where(df['recYds']>=100,3,0)
			total_pts=.1*df['rushYds']+6*df['rushTds']+df['rec']+.1*df['recYds']+rushing_bonus+receiving_bonus
		elif position=='WR':
			rushing_bonus=np.where(df['rushYds']>=100,3,0)
			receiving_bonus=np.where(df['recYds']>=100,3,0)
			total_pts=.1*df['rushYds']+6*df['recTds']+df['rec']+.1*df['recYds']+rushing_bonus+receiving_bonus
		else:
			receiving_bonus=np.where(df['recYds']>=100,3,0)
			total_pts=df['rec']+.1*df['recYds']+6*df['recTds']+receiving_bonus
		df['Fantasy Points']=total_pts
		columns=df.columns
		merged_df=pd.DataFrame(columns=columns)
		first_playerId=df['playerId'][0]
		#Calculate how many players there must be in first projection
		first_player_projections=df[df['playerId']==first_playerId]
		indices=first_player_projections.index
		num_players=indices[1]-indices[0]#indices[0]

		for i in xrange(num_players):
			#Grab the player, then all projections with that player
			player=df.iloc[i]
			player_projections=df[df.playerId==player.playerId]
			#Merged them
			player_merged=player_projections.mean()
			player_merged['player']=player.player
			player_merged['position']=player.position
			deviation=player_projections['Fantasy Points'].std()
			player_merged['FP deviation']=deviation
			merged_df=merged_df.append(player_merged, ignore_index=True)
			# merged_df.iloc[i].player=player.player
			# merged_df.iloc[i].position=player.position
			merged_df=merged_df.drop(['Unnamed: 0', 'analyst'], axis=1)
		merged_df=merged_df.sort_values('Fantasy Points', ascending=False)

		new_file='merged'+position+'.csv'
		merged_df.to_csv(new_file, index=False)




if __name__ == '__main__':
	merge()
 
 